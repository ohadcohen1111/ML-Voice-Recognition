from numpy import double
import numpy as np
from sklearn.model_selection import train_test_split

from Point import Point
from sklearn.datasets import make_classification

from rule import rule


def slope(x1, y1, x2, y2):
    m = (y2 - y1) / (x2 - x1)
    return m

def findPointBetween(x1, y1, x2, y2):
    y = (y2 + y1) / 2
    x = (x2 + x1) / 2
    p = Point(x, y, 0)
    return p



ListPoint = []
k = open("HC_Body_Temperature.txt", "r")
kk = k.readlines()

j = 0


train = []
p1 = Point(4,12,1)
p2 = Point(2,8,-1)
p3 = Point(8,3,1)
p4 = Point(10,10,-1)
train.append(p1)
train.append(p2)
train.append(p3)
train.append(p4)

for t in train:
    print (t)

n_samples = 4
# init the weight to be 1/n
w = np.full(n_samples, (1/n_samples))

def NormalizationWeight(weight):
    for i in range(len(w)):
        w[i] = w[i] / weight


predictions = np.ones(n_samples)

# change the label to (-1, 1)
for point2 in train:
    if point2.lable == 2:
        point2.lable = -1

sum = 0
r = 0
rules = []
for i in range(0, n_samples):
    j = i + 1
    for j in range(j, n_samples):
        r = r + 1
        # m of equation
        m = slope(train[i].x, train[i].y, train[j].x, train[j].y)
        pointBetween = findPointBetween(train[i].x, train[i].y, train[j].x, train[j].y)
        if m == 0:
            mPointBetween = 0
        else:
            mPointBetween = (-1 / m)
        # b of equation
        b = -mPointBetween*pointBetween.x + pointBetween.y

        print("b: ", b)
        print("m: ", mPointBetween)
        # b = -m*train[i].x + train[i].y
        k = 0
        # error for this rule
        error = 0
        # check the rule on all the points
        for point in train:
            sum = sum + 1
            # check if the point is under the equation
            y = mPointBetween * point.x + b
            if(y > point.y):
                 predictions[k] = 1
            else:
                predictions[k] = -1
            #  error on every point
            error_point = np.multiply(w[k], [predictions[k] != point.lable])
            error = error + error_point
            k = k + 1
            if error < 0.5:
                lable = 1
                error1 = 1 - error
            else:
                lable = -1
                error1 = error


        # weight of the rule
        print("Error Point: ",  error1)
        alpha = 0.5 * (np.log((1-error1) / (error1)))
        # insert to array of rules
        rules.append(rule(m, b, alpha, 1, error1))
        allWeight = 0
        for we in range(len(w)):
            exponent = np.exp(np.e, -alpha*predictions[we]*train[we].lable)
            weight = w[we]*exponent
            w[we] = weight
            # print("np.e")
            allWeight = allWeight + weight
        NormalizationWeight(allWeight)


for h in rules:
    print(h)

print("Sum: ", sum)
print("Rules: ", r)

