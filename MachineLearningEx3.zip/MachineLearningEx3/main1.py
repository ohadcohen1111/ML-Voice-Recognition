from numpy import double
import numpy as np
from sklearn.model_selection import train_test_split

from Point import Point
from sklearn.datasets import make_classification

from rule import rule


def slope(x1, y1, x2, y2):
    if (x2 - x1) == 0:
        m = 0
    else:
        m = (y2 - y1) / (x2 - x1)
    return m

def findMidpoint(x1, y1, x2, y2):
    y = (y2 + y1) / 2
    x = (x2 + x1) / 2
    p = Point(x, y, 0)
    return p

# Normalize the points to reach the total weight of 1
def NormalizationWeight(weight):
    for i_weight in range(len(array_weight)):
        array_weight[i_weight] = array_weight[i_weight] / weight


def get_min_alpha(best):
    min_alpha_index = 0
    for curr_index_rule in range(len(best)):
        if curr_index_rule != min_alpha_index and best.get(curr_index_rule).alpha < best.get(min_alpha_index).alpha:
            min_alpha_index = curr_index_rule
    return min_alpha_index

# def get_max_error(best):
#     max_index_error = 0
#     for curr_index_rule in range(len(best)):
#         if curr_index_rule != max_index_error and best.get(curr_index_rule).trueError > best.get(max_index_error).trueError:
#             max_index_error = curr_index_rule
#     return max_index_error

# array of all points in the world
ListPoint = []
# read the data
file = open("HC_Body_Temperature.txt", "r")
# array of lines from data
fileLines = file.readlines()

# create points from data
for line in fileLines:
    line_split = line.split()
    ListPoint.append(Point(double(line_split[0]), double(line_split[2]), int(line_split[1])))



all_average = 0

for ii in range(100):

    # split the data to train and test
    train, test = train_test_split(ListPoint, test_size=0.5)

    # total of points
    n_samples = len(train)

    # init the weight to be 1/n
    array_weight = np.full(n_samples, (1 / n_samples))


    # prediction array
    predictions = np.zeros(n_samples)

    # change the label to (-1, 1)
    for point_train in train:
        if point_train.label == 2:
            point_train.label = -1

    array_rules = []

    # all possible straight equations from two points (rules)
    for i in range(0, n_samples):
        j = i + 1
        for j in range(j, n_samples):
            # slope of equation
            slope_m = slope(train[i].x, train[i].y, train[j].x, train[j].y)
            # finding the midpoint
            midpoint = findMidpoint(train[i].x, train[i].y, train[j].x, train[j].y)
            if slope_m == 0:
                reverse_slope = 0
            else:
                reverse_slope = (-1 / slope_m)
            # b of equation
            b_reverse = ((-1 * reverse_slope) * midpoint.x) + midpoint.y
            #
            idx_predict = 0
            # error for this rule
            true_error = 0
            alpha = 0
            # check the rule on all the points
            for point in train:
                # check if the point is under the equation
                y = reverse_slope * point.x + b_reverse
                # check whether the point is above the line or below
                # if y > point.y -> the point is below the line
                if y > point.y:
                    predictions[idx_predict] = 1
                else:
                    # the point is above the line
                    predictions[idx_predict] = -1
                #  error on every point
                error_point = np.multiply(array_weight[idx_predict], [predictions[idx_predict] != point.label])
                # schema of all errors
                true_error = true_error + error_point
                # If the true error > 0.5 we want the opposite rule
                if true_error > 0.5:
                    label = 1
                    final_true_error = 1 - true_error
                else:
                    label = -1
                    final_true_error = true_error
                idx_predict = idx_predict + 1
            # weight of the rule
            alpha = 0.5 * (np.log((1-final_true_error) / final_true_error))
            # insert to array of rules
            array_rules.append(rule(reverse_slope, b_reverse, alpha, label, final_true_error))
            # The weight of all the points (for normalization)
            all_points_weight = 0
            # changing the weights of the points according to the error
            for idx_weight in range(len(array_weight)):
                # calculates the new weight of the point -> e^(-alfa*h(x)*label(x))
                e_exponent = np.exp(np.e, (-1 * alpha) * (predictions[idx_weight] * train[idx_weight].label))
                weight_point = array_weight[idx_weight] * e_exponent
                # update the new weight
                array_weight[idx_weight] = weight_point
                # sum the weights of all points
                all_points_weight = all_points_weight + weight_point
            # normalize the points
            NormalizationWeight(all_points_weight)

    # list of the best rules
    best_rules = {}

    # initialize the list in the first 8 rules
    for idx_best_rules in range(8):
        best_rules[idx_best_rules] = array_rules[idx_best_rules]


    for idx_rule in range(len(array_rules)):
        min_alpha = get_min_alpha(best_rules)
        if array_rules[idx_rule].alpha > best_rules.get(min_alpha).alpha:
            best_rules[min_alpha] = array_rules[idx_rule]
        # max_error = get_max_error(best_rules)
        # if array_rules[idx_rule].trueError < best_rules.get(max_error).trueError:
        #     best_rules[max_error] = array_rules[idx_rule]


    # array prediction of the test
    predict_test = np.zeros(len(test))

    for point_test in range(len(test)):
        fx = 0
        for i_best_rules in range(len(best_rules)):
            yRule = (best_rules[i_best_rules].m * test[point_test].x) + best_rules[i_best_rules].b
            # check whether the point is above the line or below
            if test[point_test].y > yRule:
                # y of the point is above the line
                signRule = best_rules[i_best_rules].sighUp
            else:
                # y of the point is below the line
                signRule = (-1 * best_rules[i_best_rules].sighUp)

            fx = fx + (best_rules[i_best_rules].alpha * signRule)
        if fx > 0:
            predict_test[point_test] = 1
        else:
            predict_test[point_test] = -1

    # print(predict_test)

    # Analyzing the data on what percentage of the rules are right
    true_sum = 0
    for p_idx in range(len(test)):
        if test[p_idx].label == predict_test[p_idx]:
            true_sum = true_sum + 1

    average = true_sum / len(test)
    all_average = all_average + average
    print("iteration: ", ii)
print("All the average on 100 times: ", (all_average / 100))
    # print("Sum: ", true_sum)
    # print("Average of the rules: ", average)




    # # Analyzing the data on the train
    #
    # # array prediction of the test
    # predict_train = np.zeros(len(train))
    #
    # for point2_train in range(len(train)):
    #     fx = 0
    #     for i_best_rules in range(len(best_rules)):
    #         yRule = (best_rules[i_best_rules].m * train[point2_train].x) + best_rules[i_best_rules].b
    #         # check whether the point is above the line or below
    #         if train[point2_train].y > yRule:
    #             # y of the point is above the line
    #             signRule = best_rules[i_best_rules].sighUp
    #         else:
    #             # y of the point is below the line
    #             signRule = (-1 * best_rules[i_best_rules].sighUp)
    #
    #         fx = fx + (best_rules[i_best_rules].alpha * signRule)
    #     if fx > 0:
    #         predict_train[point2_train] = 1
    #     else:
    #         predict_train[point2_train] = -1
    #
    # print(predict_train)
    #
    # # for rrr in array_rules:
    # #     print("arrayR ----> ", rrr)
    # #
    # #
    # # for rr in best_rules:
    # #     print("RR: ", best_rules.get(rr))
    #
    #
    # # Analyzing the data on what percentage of the rules are right
    # true_sum_train = 0
    # for t_idx in range(len(train)):
    #     if train[t_idx].label == predict_train[t_idx]:
    #         true_sum_train = true_sum_train + 1
    #
    # average_train = true_sum_train / len(train)
    #
    # print("Sum: ", true_sum_train)
    # print("Average of the rules: ", average_train)
